package gapp.model.dao;

import gapp.model.ApplicationStatus;

public interface ApplicationStatusDao {
	ApplicationStatus newStatus(ApplicationStatus status);

}
