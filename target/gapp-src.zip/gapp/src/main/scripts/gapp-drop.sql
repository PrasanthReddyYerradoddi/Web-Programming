drop table applicationstatus;

drop table applicationadditionalfields;

drop table degree CASCADE;

drop table application CASCADE;

drop table programs;

drop table users;

drop table departments;

drop sequence hibernate_sequence;
