package gapp.model.dao;

import gapp.model.Departments;
import gapp.model.Programs;

import java.util.List;

public interface ProgramsDao {

	Programs setPrograms(Programs pgm);

	Programs getProgram(Integer id);

	List<Programs> getDepartments(Departments department);
	
	List<Programs> getPrograms();
	
	List<Programs> getPrograms(Departments id);
	
	void removeProgram(Integer id);
}
