package gapp.model.dao;

import gapp.model.Degree;

public interface DegreeDao {

	Degree newDegree(Degree degree);
	
	Degree getDegree(Integer id);
	
	void delDegree(Integer id);
}
